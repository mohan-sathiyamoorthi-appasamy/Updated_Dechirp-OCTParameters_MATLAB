%% PSF & Sensitivity Roll -off
function OCTSystemParameter(InfRawDir,MovandRefArmDir, dechirpData)
    %dechirpData = load(dechirpData);
    nCameraPixels = 2048;
    rawFiles = dir(fullfile(InfRawDir,'\*.raw'));
    numberOfRawFiles = length(rawFiles);

    
for iPosition = 1:numberOfRawFiles
    interferencePatternFileName = sprintf ('Inf_%04d.raw', (iPosition-1));
    movingArmFileName = sprintf ('MovArm_%04d.raw', (iPosition-1));
    refArmFileName = sprintf ('RefArm_%04d.raw', (iPosition-1));
    
    % Read files for different patterns
    interferenceRawData = readOCTrawFile (fullfile (InfRawDir, interferencePatternFileName));
    movingArmRawData = readOCTrawFile (fullfile (MovandRefArmDir, movingArmFileName));
    avgmovingArmRawData = mean (movingArmRawData, 2);
    
    refArmRawData = readOCTrawFile (fullfile (MovandRefArmDir, refArmFileName));
    avgrefArmRawData = mean (refArmRawData, 2);
    
    meanSpectra = (avgmovingArmRawData+avgrefArmRawData);
    %%  Background Subtraction
    fringe=interferenceRawData(:,1)- meanSpectra;
   
   
    %%  Interpolation accordance with corrected resampled function
    vq=interp1(fringe,dechirpData,'spline','extrap');
    
    %%   FFT of Windowed Data & crop it
    window = hann(nCameraPixels);
    dataPSF2= fft(vq.*window);
    
    calibratedPSF = abs(dataPSF2);
    unCalibratedPSF = abs(fft(fringe));
    [~, positionInArray] = max(calibratedPSF);
    positionInMM = positionInArray *4.9/1000;
    
    %%  PSF & Sensitivity Roll - off
    xScaleRange2 = (1 : nCameraPixels/2).*4.9/1000;
    figure(2),plot(xScaleRange2,calibratedPSF(1 : nCameraPixels/2),'b'),hold on,
    plot(xScaleRange2,unCalibratedPSF(1 : nCameraPixels/2),'r'), 
    figure(3),plot(xScaleRange2,20*log10(calibratedPSF(1 : nCameraPixels/2))),hold on, 
    
    %% Axial Resolution
    gf1 = fit((1:length(calibratedPSF(1 : nCameraPixels/2)))',((calibratedPSF(1 : nCameraPixels/2)).^2)','gauss1');
    tmp     = coeffvalues(gf1);
    x1      = tmp(3);
    axialResolution = x1*1.665;
    figure(4), plot (positionInMM, axialResolution, 'ko-'); hold on;
    
    fprintf('\nAxial Resolution of Fringe %d: %f\n',iPosition, axialResolution);
end

figure(2); xlabel('Position in mm'),ylabel('Amplitude'),title('PSF'),legend('Calibrated PSF','UnCalibrated PSF');
%saveas(gcf,sprintf('HandHeldOCTPSF.pdf'));
figure(3), xlabel('Position in mm'),ylabel('Amplitude in dB'),title('Sensitivity Roll-off');
%saveas(gcf,sprintf('HandHeldOCTSensitivityRollOff.pdf'));
figure(4), xlabel('Position in mm'),ylabel('Axial Resolution'),title('Axial Resolution vs Depth'),legend('Axial Resolution (in microns)'); xlim ([0 6]); ylim ([0 5]);
%saveas(gcf,sprintf('HandHeldOCTAxialResolution.pdf'));
    