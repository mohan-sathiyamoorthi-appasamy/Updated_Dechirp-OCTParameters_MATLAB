function Yth = IntensityProfile(RawDir,avgBScanSpectra,noEyeNoiseFloorBscan,dechirpData)  
%% OCT Reconstruction
nImage = 1;
bScanImage = AppaOCTBScanImageReconstruction_Modified(RawDir,avgBScanSpectra,nImage,0,0,dechirpData);

%% Normalization Process
normImage = NormalizationProcess(bScanImage,noEyeNoiseFloorBscan);
axialIntensity = (mean(normImage,2));
x = (1:length(axialIntensity));
figure(1),plot(x,axialIntensity);
[~,Yth] = ginput(1);
end
