function avgBScanSpectra = noEyeBackgroundMeasurement(RefRawDir)
nAscanPerBscan = 2000;
NPixel = 2048;
%% Read Reference File
    fid = fopen(fullfile(RefRawDir, '00001.raw'), 'r');
    refRawDataStream = fread(fid, 'int16', 'l');
    reshapedRefRawData = reshape(refRawDataStream, [NPixel, nAscanPerBscan, 1]);% before 2048 2000
    fclose(fid);
    %% Size of Interference Fringe
    [NPixel,nAscanPerBscan] = size(reshapedRefRawData);
    
    %% Type Conversion & subtract (2^16)/2
    typeConvertedBScanCameraRawData = double((reshapedRefRawData) - 32768);
    bScanData = typeConvertedBScanCameraRawData';
    avgBScanSpectra = mean(bScanData, 1);                                                                                                                                                                                                                                                                
end
