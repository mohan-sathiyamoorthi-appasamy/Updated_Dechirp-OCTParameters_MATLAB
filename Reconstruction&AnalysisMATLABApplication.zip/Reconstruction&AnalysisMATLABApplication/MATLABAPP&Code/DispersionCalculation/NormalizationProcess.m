function normImage = NormalizationProcess(bScanImage,noEyeNoiseFloorBscan)
FinalImage = bScanImage + noEyeNoiseFloorBscan;
% Image Normalization
baseImageFloor = 44;
dynamicRange = 55;
grayScaleUnitsPerDB = 255/dynamicRange;
normImage = uint8(grayScaleUnitsPerDB*(FinalImage-baseImageFloor));
end