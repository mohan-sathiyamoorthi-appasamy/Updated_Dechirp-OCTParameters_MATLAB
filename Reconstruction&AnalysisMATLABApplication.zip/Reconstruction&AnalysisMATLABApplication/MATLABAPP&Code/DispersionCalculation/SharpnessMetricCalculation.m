function M = SharpnessMetricCalculation(normImage,Threshold)
%cropImage=normImage(:,851:1150);
%for noAscan = 1 : 300
%axialIntensity = cropImage(:,noAscan);
axialIntensity = (mean(normImage,2));
x = (1:length(axialIntensity));
%noiseFloor = 50;
%figure(1),plot(x,axialIntensity),pause;
%th = input('User defined Threshold');
%Threshold = noiseFloor - userDefThreshold;

%% Find Number of Pixels at above the threshold
% Create Intersect Line
interSectLine  = ones(1,length(x)).*Threshold;
%figure(1),plot(x,axialIntensity),hold on,plot(x,interSectLine),xlabel('Pixels'),ylabel('Intensity in dB'),title('Intensity Profile'),legend('Intensity Profile','Threshold');

%% Find Pixel Start and End Point 
[interSectPoints,~] = curveintersect(x, interSectLine, x, double(axialIntensity));
startPixel = floor(interSectPoints(1));
endPixel = floor(interSectPoints(end));

%% Find Valid Pixels Above Threshold
totalNumberPixels = length(axialIntensity(startPixel:endPixel)); 
 
%% Sharpness Metric
M = 1 / totalNumberPixels;
%end

end