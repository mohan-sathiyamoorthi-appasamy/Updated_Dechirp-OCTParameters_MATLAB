%% OCT Reconstruction
function [a2Optimized,a3Optimized,noEyeNoiseFloorBscan] = ThresholdBasedOptimization(RawDirRef,RawDirHuman,dechirpData)
%% B-Scan Image Reconstruction with Noise Flattened Process
nAscanPerBscan = 2000;
%% Raw Reference or No Eye B-Scan Image Directory
%RawDirRef = '.\Ref&HumanEyeData\RefData';
avgBScanSpectra = noEyeBackgroundMeasurement(RawDirRef);
%% Initially set a2 & a3 is zero for Background Image Reconstruction
noEyeBScanImage = AppaOCTBScanImageReconstruction_Modified(RawDirRef,avgBScanSpectra,1,0,0,dechirpData);
%% Noise Floor Determination
windowSize=5;
noiseAvg=mean(noEyeBScanImage,2);% dBScalePSF is the reconstructed B-scan (after logarithm step) of a reference scan
noiseFloor=filter(ones(1,windowSize)/windowSize,1,noiseAvg);
noiseFloor(1:4)=noiseFloor(5);
noiseFlatten = max(noiseFloor) - noiseFloor;
noEyeNoiseFloor = noiseFlatten(:,1);
noEyeNoiseFloorBscan = repmat(noEyeNoiseFloor,1,nAscanPerBscan);

%% Raw Human Eye B-Scan Image Directory
nImage = 1;
%RawDirHuman = '.\Ref&HumanEyeData\HumanEye\Deepa';

%% Select threshold from Intensity Profile
userDefinedThreshold = IntensityProfile(RawDirHuman,avgBScanSpectra,noEyeNoiseFloorBscan,dechirpData);

%% Automatic Second Order Dispersion Parameter Calculation  
ctr = 1;
for a2 = 2000e-30 : 100e-30 :7000e-30
%for a2 = 6900e-30
%% Image Reconstruction
bScanImage = AppaOCTBScanImageReconstruction_Modified(RawDirHuman,avgBScanSpectra,nImage,a2,0,dechirpData);
%% Normalization Process
normImage = NormalizationProcess(bScanImage,noEyeNoiseFloorBscan);
%% Sharpness Metric Calculation
M(ctr)= SharpnessMetricCalculation(normImage,userDefinedThreshold);
%Metric(ctr) = mean(M);
a2Val(ctr) = a2;
ctr = ctr +1;
end
 
%figure(1),plot(a2Val,M),xlabel('a2 Coefficient'),ylabel('Metric');
[maxSharpValues,pos]= max(M);
%pos = find(M==maxSharpValues,1,'last');
a2Optimized = a2Val(pos);

%% Automatic Third Order Dispersion Parameter Calculation  
ctr = 1;
for a3 = 1000e-45 : 500e-45 :10000e-45
%% Image Reconstruction
a2OptimizedBScanImage = AppaOCTBScanImageReconstruction_Modified(RawDirHuman,avgBScanSpectra,nImage,a2Optimized,a3,dechirpData);
%% Normalization Process
a2OptimizednormImage = NormalizationProcess(a2OptimizedBScanImage,noEyeNoiseFloorBscan);
%% Sharpness Metric Calculation
M1(ctr) = SharpnessMetricCalculation(a2OptimizednormImage,userDefinedThreshold);
%Metric(ctr) = mean(M);
a3Val(ctr) = a3;
ctr = ctr +1;
end
%figure(2),plot(a3Val,M1),xlabel('a3 Coefficient'),ylabel('Metric');
[maxSharpValues,pos]= max(M1);
%pos = find(M==maxSharpValues,1,'last');
a3Optimized = a3Val(pos);

%% Final Image Reconstruction with Optimized Dispersion Coefficients
%% Image Reconstruction
%FinalImage = AppaOCTBScanImageReconstruction_Modified(RawDirHuman,avgBScanSpectra,nImage,a2Optimized,a3Optimized);
%% Normalization Process
%FinalNormImage = NormalizationProcess(FinalImage,noEyeNoiseFloorBscan);
%figure(3),imshow(FinalNormImage,[]);
end