clear all;
%% B-Scan Image Reconstruction with Noise Flattened Process
nAscanPerBscan = 2000;
%% Raw Reference or No Eye B-Scan Image Directory
RawDirRef = '.\RawDirRef';
avgBScanSpectra = noEyeBackgroundMeasurement(RawDirRef);

noEyeBScanImage = AppaOCTBScanImageReconstruction_Modified(RawDirRef,avgBScanSpectra,1);
%% Noise Floor Determination
windowSize=5;
noiseAvg=mean(noEyeBScanImage,2);% dBScalePSF is the reconstructed B-scan (after logarithm step) of a reference scan
noiseFloor=filter(ones(1,windowSize)/windowSize,1,noiseAvg);
noiseFloor(1:4)=noiseFloor(5);
noiseFlatten = max(noiseFloor) - noiseFloor;
noEyeNoiseFloor = noiseFlatten(:,1);
noEyeNoiseFloorBscan = repmat(noEyeNoiseFloor,1,nAscanPerBscan);

%% Reconstruction Part Only
nImage = 1;
% Raw Human Eye B-Scan Image Directory
RawDirHuman = '.\CUDA_Ref_HumanEye_RawFile';
bScanImage = AppaOCTBScanImageReconstruction_Modified(RawDirHuman,avgBScanSpectra,nImage);

%% Normalization Process
for iImage = 1 : nImage
% Add Noise Floor to B-Scan Image
FinalImage = bScanImage(:,:,iImage) + noEyeNoiseFloorBscan;
% Image Normalization
baseImageFloor = 44;
dynamicRange = 55;
grayScaleUnitsPerDB = 255/dynamicRange;
normImage = uint8(grayScaleUnitsPerDB*(FinalImage-baseImageFloor));
figure(4),imagesc(normImage,[20 210]);colormap(gray);
imwrite(normImage,sprintf('NormalizedImage_ModelEye%05d.tif',iImage));
% Change Aspect Ratio
resizedNormImage = imresize(normImage,[1000 1000]);
%imwrite(resizedNormImage,sprintf('ResizedNormalizedImage%05d.tif',iImage));
end


%% Display Image & Plot
% figure(1),imshow(FinalImage,[]);
% figure(2),plot(noEyeNoiseFloor),xlabel('Pixels'),ylabel('Intensity in dB'),title('Noise Floor in Reference Data');
% figure(3),plot(mean(bScanImage(:,:,1),2),'r'),hold on,plot(mean(FinalImage,2),'b'),xlabel('Pixels'),ylabel('Intensity in dB'),title('Comparison of Intensity Profile of Before & After Noise Flatten'),legend('Before Noise Flatten','After Noise Flatten');

